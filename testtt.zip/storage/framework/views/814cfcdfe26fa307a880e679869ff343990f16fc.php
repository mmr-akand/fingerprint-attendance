<?php $__env->startSection('content'); ?>
<form action="" class="signup-form form-small-space" id="signup-form" method="POST">
    <?php echo csrf_field(); ?>

    <div class="log-card">
        <div class="log-block">
            <h4 class="log-title text-center">Log In</h4>
            <div class="form-group <?php if($errors->first('phone')!=null): ?> has-danger <?php endif; ?>">
                <div>
                    <label for="phone" class="label-log">Phone</label>
                    <div class="input-phone-group has-form-control-lg">
                        <input class="form-control form-control-lg form-control-danger input-phone" value="<?php echo e(old('phone')); ?>" id="phone" name="phone" type="text">
                        <span class="country-code">+88</span>
                    </div>                            
                </div>
                <div class="form-control-feedback"><?php if($errors->first('phone')!=null): ?> <?php echo e($errors->first('phone')); ?> <?php endif; ?></div>
            </div>
            <div class="form-group <?php if($errors->first('password')!=null): ?> has-danger <?php endif; ?>">
                <label for="password" class="label-log">Password</label>
                <input class="form-control form-control-lg form-control-danger" value="" id="password" name="password" type="password">
                <div class="form-control-feedback"><?php if($errors->first('password')!=null): ?> <?php echo e($errors->first('password')); ?> <?php endif; ?></div>
            </div>
            <button class="btn btn-primary btn-lg mt-15 btn-block btn-sign">Log in</button>
        </div>
    </div>
</form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('auth.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/fingerprint-attendance/resources/views/auth/login.blade.php ENDPATH**/ ?>